# desafio-lampada
Pequeno projeto criando um sistema simples que liga e desliga uma lâmpada, e caso ela esteja quebrada, os botões de ligar e desligar não funcionarão.
![image](https://user-images.githubusercontent.com/44215511/225363761-60a151b1-9073-44f1-84f8-a825ab601f57.png)
========================================================================================================
A imagem abaixo mostra como a lâmpada ficará caso o usuário clique no botão de ligar.
![image](https://user-images.githubusercontent.com/44215511/225364205-9899af0f-ded2-45e9-984a-63dc30897c5b.png)
========================================================================================================
Ao clicar no botão de desligar, a lâmpada voltará ao seu estado original.
![image](https://user-images.githubusercontent.com/44215511/225364408-b2e35aea-b73b-446c-b42c-191de2720db6.png)
========================================================================================================
Ao clicar na lâmpada, ela irá quebrar e parar de funcionar, invalidando a opção de pressionar o botão de ligar e fazendo com que as imagens sejam trocadas
![image](https://user-images.githubusercontent.com/44215511/225364468-3f55a93e-ba94-4188-a5d6-281c41c2de4d.png)
